// Variables del juego
let truck;
let obstacles = [];
let score = 0;
let gameOver = false;
let gamePhase = 'campo'; // 'campo', 'entrada_ciudad', 'ciudad'
let obstacleSpeed = 3;
let lastObstacleSpawnTime = 0;
const OBSTACLE_SPAWN_INTERVAL = 800; // milisegundos

// Dimensiones del camión
const TRUCK_WIDTH = 50;
const TRUCK_HEIGHT = 80;

// Colores
const FIELD_GREEN = '#6B8E23';
const ROAD_GRAY = '#606060';
const CITY_BLUE = '#87CEEB';
const BUILDING_COLOR = '#A9A9A9';
const LINE_YELLOW = '#FFD700';

function setup() {
  createCanvas(600, 800);
  noSmooth(); // Para un estilo pixelado

  // Inicializa el camión en el centro inferior
  truck = {
    x: width / 2 - TRUCK_WIDTH / 2,
    y: height - TRUCK_HEIGHT - 20,
    width: TRUCK_WIDTH,
    height: TRUCK_HEIGHT,
    speed: 5
  };
}

function draw() {
  if (gameOver) {
    displayGameOver();
    return;
  }

  // Actualiza la fase del juego según la puntuación
  updateGamePhase();
  // Dibuja el fondo y la carretera
  drawBackground();
  drawRoad();

  // Mueve y dibuja el camión
  handleTruckMovement();
  drawTruck();

  // Genera y actualiza obstáculos
  spawnObstacles();
  updateAndDrawObstacles();

  // Muestra la puntuación
  displayScore();
}

function updateGamePhase() {
  if (score < 50) {
    gamePhase = 'campo';
    obstacleSpeed = 3;
  } else if (score < 200) {
    gamePhase = 'entrada_ciudad';
    obstacleSpeed = 5;
  } else if (score < 1000) {
    gamePhase = 'ciudad';
    obstacleSpeed = 8; // Más rápido en la ciudad
  } else {
    // ¡Has ganado!
    gameOver = true;
    // Podrías mostrar un mensaje de victoria aquí
  }
}

function drawBackground() {
  if (gamePhase === 'campo') {
    background(FIELD_GREEN); // Campo
  } else if (gamePhase === 'entrada_ciudad') {
    // Transición de campo a ciudad
    let transitionProgress = map(score, 50, 200, 0, 1);
    let r = lerp(red(FIELD_GREEN), red(CITY_BLUE), transitionProgress);
    let g = lerp(green(FIELD_GREEN), green(CITY_BLUE), transitionProgress);
    let b = lerp(blue(FIELD_GREEN), blue(CITY_BLUE), transitionProgress);
    background(r, g, b);
    // Dibuja algunas líneas de edificios a los lados
    fill(BUILDING_COLOR);
    rect(0, 0, width / 4, height);
    rect(width * 3 / 4, 0, width / 4, height);
  } else if (gamePhase === 'ciudad') {
    background(CITY_BLUE); // Cielo de ciudad
    // Dibuja edificios
    fill(BUILDING_COLOR);
    rect(0, 0, width / 4, height);
    rect(width * 3 / 4, 0, width / 4, height);
  }
}

function drawRoad() {
  fill(ROAD_GRAY);
  rect(width / 4, 0, width / 2, height); // Carretera

  // Líneas de la carretera
  stroke(LINE_YELLOW);
  strokeWeight(5);
  // Líneas punteadas (simulan movimiento hacia abajo)
  for (let i = 0; i < height; i += 60) {
    line(width / 2, (i + frameCount * obstacleSpeed * 0.5) % height, width / 2, (i + 30 + frameCount * obstacleSpeed * 0.5) % height);
  }
  noStroke();
}

function drawTruck() {
  fill(255, 0, 0); // Camión rojo
  rect(truck.x, truck.y, truck.width, truck.height);
  // Ventana
  fill(0, 0, 100);
  rect(truck.x + 10, truck.y + 10, truck.width - 20, 20);
  // Ruedas
  fill(50);
  ellipse(truck.x + 10, truck.y + truck.height - 10, 15, 15);
  ellipse(truck.x + truck.width - 10, truck.y + truck.height - 10, 15, 15);
  ellipse(truck.x + 10, truck.y + 25, 15, 15);
  ellipse(truck.x + truck.width - 10, truck.y + 25, 15, 15);
}

function handleTruckMovement() {
  if (keyIsDown(65)) { // Tecla 'A'
    truck.x -= truck.speed;
  }
  if (keyIsDown(68)) { // Tecla 'D'
    truck.x += truck.speed;
  }
  // Limita el camión a la carretera
  truck.x = constrain(truck.x, width / 4, width * 3 / 4 - truck.width);
}

function spawnObstacles() {
  if (millis() - lastObstacleSpawnTime > OBSTACLE_SPAWN_INTERVAL) {
    let obstacleType;
    if (gamePhase === 'campo') {
      let r = random(1);
      if (r < 0.3) obstacleType = 'vaca';
      else if (r < 0.6) obstacleType = 'cerca';
      else if (r < 0.8) obstacleType = 'oveja';
      else obstacleType = 'auto'; // Algún que otro auto
    } else if (gamePhase === 'entrada_ciudad' || gamePhase === 'ciudad') {
      let r = random(1);
      if (r < 0.6) obstacleType = 'auto';
      else if (r < 0.8) obstacleType = 'camion';
      else obstacleType = 'autobus';
    }

    let obstacleWidth = random(30, 60);
    let obstacleHeight = random(30, 80);
    let xPos = random(width / 4 + 10, width * 3 / 4 - 10 - obstacleWidth); // Dentro de la carretera

    obstacles.push({
      x: xPos,
      y: -obstacleHeight, // Aparece desde arriba
      width: obstacleWidth,
      height: obstacleHeight,
      type: obstacleType
    });

    lastObstacleSpawnTime = millis();
  }
}

function updateAndDrawObstacles() {
  for (let i = obstacles.length - 1; i >= 0; i--) {
    let obs = obstacles[i];
    obs.y += obstacleSpeed;

    // Dibuja el obstáculo según su tipo
    drawObstacle(obs);

    // Colisión
    if (
      truck.x < obs.x + obs.width &&
      truck.x + truck.width > obs.x &&
      truck.y < obs.y + obs.height &&
      truck.y + truck.height > obs.y
    ) {
      gameOver = true;
    }

    // Si el obstáculo sale de la pantalla, lo elimina y suma puntos
    if (obs.y > height) {
      obstacles.splice(i, 1);
      score += 5; // Cada obstáculo pasado son 5 puntos
    }
  }
}

function drawObstacle(obs) {
  push();
  fill(0); // Color por defecto si no se define

  switch (obs.type) {
    case 'vaca':
      fill(150, 100, 50); // Marrón
      rect(obs.x, obs.y, obs.width, obs.height);
      fill(255); // Manchas blancas
      ellipse(obs.x + obs.width * 0.2, obs.y + obs.height * 0.2, obs.width * 0.3, obs.height * 0.3);
      ellipse(obs.x + obs.width * 0.8, obs.y + obs.height * 0.7, obs.width * 0.3, obs.height * 0.3);
      break;
    case 'cerca':
      fill(100, 70, 40); // Madera
      rect(obs.x, obs.y, obs.width, obs.height);
      fill(150, 120, 90); // Postes
      rect(obs.x + obs.width / 4 - 2, obs.y, 4, obs.height);
      rect(obs.x + obs.width * 3 / 4 - 2, obs.y, 4, obs.height);
      break;
    case 'oveja':
      fill(220); // Blanco grisáceo
      ellipse(obs.x + obs.width / 2, obs.y + obs.height / 2, obs.width, obs.height);
      fill(50); // Cara
      ellipse(obs.x + obs.width / 2, obs.y + obs.height * 0.2, obs.width * 0.4, obs.height * 0.3);
      break;
    case 'auto':
      fill(random(0, 255), random(0, 255), random(0, 255)); // Color aleatorio
      rect(obs.x, obs.y, obs.width, obs.height);
      fill(0); // Ruedas
      rect(obs.x, obs.y + obs.height - 10, 10, 10);
      rect(obs.x + obs.width - 10, obs.y + obs.height - 10, 10, 10);
      break;
    case 'camion':
      fill(random(100, 200), random(100, 200), random(100, 200)); // Colores más oscuros
      rect(obs.x, obs.y, obs.width, obs.height * 1.5); // Más alto que un auto
      fill(0); // Ruedas
      rect(obs.x, obs.y + obs.height * 1.5 - 10, 10, 10);
      rect(obs.x + obs.width - 10, obs.y + obs.height * 1.5 - 10, 10, 10);
      rect(obs.x, obs.y + obs.height * 0.5 - 10, 10, 10);
      rect(obs.x + obs.width - 10, obs.y + obs.height * 0.5 - 10, 10, 10);
      break;
    case 'autobus':
      fill(random(50, 150), random(50, 150), random(50, 150)); // Colores grises/azules
      rect(obs.x, obs.y, obs.width * 1.2, obs.height * 2); // Más ancho y alto
      fill(0); // Ventanas
      rect(obs.x + 5, obs.y + 5, obs.width * 1.2 - 10, obs.height * 0.4);
      fill(0); // Ruedas
      rect(obs.x, obs.y + obs.height * 2 - 10, 10, 10);
      rect(obs.x + obs.width * 1.2 - 10, obs.y + obs.height * 2 - 10, 10, 10);
      break;
  }
  pop();
}


function displayScore() {
  fill(255);
  textSize(24);
  textAlign(LEFT, TOP);
  text('Puntos: ' + score, 10, 10);

  // Mensaje de victoria
  if (score >= 1000 && !gameOver) {
    fill(0, 200, 0);
    textSize(48);
    textAlign(CENTER, CENTER);
    text('¡HAS GANADO!', width / 2, height / 2 - 50);
    textSize(24);
    text('¡Felicidades, transportaste la comida!', width / 2, height / 2);
    gameOver = true; // Asegúrate de que el juego termine aquí
  }
}

function displayGameOver() {
  background(0, 150); // Fondo oscuro semitransparente
  fill(255, 0, 0); // Texto rojo
  textSize(64);
  textAlign(CENTER, CENTER);
  text('GAME OVER', width / 2, height / 2 - 50);
  fill(255); // Texto blanco
  textSize(32);
  text('YEAAAAAAAAAAAAAAAAAAAAAAAAH!', width / 2, height / 2 + 20);
  textSize(24);
  text('Puntos Finales: ' + score, width / 2, height / 2 + 80);
  text('Presiona R para Reiniciar', width / 2, height / 2 + 120);
}

function keyPressed() {
  if (gameOver && (key === 'r' || key === 'R')) {
    resetGame();
  }
}

function resetGame() {
  score = 0;
  gameOver = false;
  gamePhase = 'campo';
  obstacleSpeed = 3;
  obstacles = [];
  lastObstacleSpawnTime = 0;
  truck.x = width / 2 - TRUCK_WIDTH / 2;
  truck.y = height - TRUCK_HEIGHT - 20;
}